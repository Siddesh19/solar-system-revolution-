
Exceute this program using following command.
g++ solarSystem.cpp -o s.out -lglut -lGLU -lGL
